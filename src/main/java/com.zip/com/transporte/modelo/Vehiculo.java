package com.transporte.modelo;

import java.util.Objects;

/**
 * Clase abstracta que representa un vehículo en el sistema de transporte
 * @author SistemaTransporte
 * @version 1.0
 */
public abstract class Vehiculo {
    private String idVehiculo;
    private String marca;
    private String modelo;
    private double capacidadMaxima;
    protected String estado;
    
    /**
     * Constructor por defecto
     */
    public Vehiculo() {
        this.estado = "DISPONIBLE";
    }
    
    /**
     * Constructor con parámetros
     * @param idVehiculo Identificador único del vehículo
     * @param marca Marca del vehículo
     * @param modelo Modelo del vehículo
     * @param capacidadMaxima Capacidad máxima en kg
     */
    public Vehiculo(String idVehiculo, String marca, String modelo, double capacidadMaxima) {
        this.idVehiculo = idVehiculo;
        this.marca = marca;
        this.modelo = modelo;
        this.capacidadMaxima = capacidadMaxima;
        this.estado = "DISPONIBLE";
    }
    
    // Getters y Setters
    public String getIdVehiculo() { return idVehiculo; }
    public void setIdVehiculo(String idVehiculo) { this.idVehiculo = idVehiculo; }
    
    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }
    
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }
    
    public double getCapacidadMaxima() { return capacidadMaxima; }
    public void setCapacidadMaxima(double capacidadMaxima) { this.capacidadMaxima = capacidadMaxima; }
    
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    
    /**
     * Calcula la capacidad útil del vehículo
     * @return capacidad útil en kg
     * @throws UnsupportedOperationException si no está implementado
     */
    public double getCapacidadUtil() {
        // TODO: Implementar cálculo según tipo de vehículo
        throw new UnsupportedOperationException("Método no implementado");
    }
    
    /**
     * Calcula la eficiencia del vehículo
     * @return eficiencia en km/kg o km/L
     */
    public abstract double calcularEficiencia();
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vehiculo vehiculo = (Vehiculo) o;
        return Objects.equals(idVehiculo, vehiculo.idVehiculo);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(idVehiculo);
    }
}
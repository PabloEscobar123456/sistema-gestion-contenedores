package com.transporte.modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa una ruta de transporte
 * @author SistemaTransporte
 */
public class Ruta {
    private String idRuta;
    private double distancia;
    private int tiempoEstimado;
    private List<Vehiculo> vehiculosAsignados;
    
    /**
     * Constructor de ruta
     * @param idRuta Identificador de la ruta
     * @param distancia Distancia en kilómetros
     * @param tiempoEstimado Tiempo estimado en minutos
     */
    public Ruta(String idRuta, double distancia, int tiempoEstimado) {
        this.idRuta = idRuta;
        this.distancia = distancia;
        this.tiempoEstimado = tiempoEstimado;
        this.vehiculosAsignados = new ArrayList<>(); // Relación 1:N
    }
    
    /**
     * Asigna un vehículo a esta ruta
     * @param vehiculo Vehículo a asignar
     * @return true si se asignó correctamente
     */
    public boolean asignarVehiculo(Vehiculo vehiculo) {
        if (vehiculo != null && !vehiculosAsignados.contains(vehiculo)) {
            return vehiculosAsignados.add(vehiculo);
        }
        return false;
    }
    
    /**
     * Elimina un vehículo de la ruta
     * @param vehiculo Vehículo a eliminar
     * @return true si se eliminó correctamente
     */
    public boolean eliminarVehiculo(Vehiculo vehiculo) {
        return vehiculosAsignados.remove(vehiculo);
    }
    
    /**
     * Calcula el tiempo total considerando todos los vehículos
     * @return Tiempo total en minutos
     */
    public double calcularTiempoTotal() {
        // TODO: Implementar cálculo considerando múltiples factores
        throw new UnsupportedOperationException("Método no implementado");
    }
    
    // Getters y Setters
    public String getIdRuta() { return idRuta; }
    public void setIdRuta(String idRuta) { this.idRuta = idRuta; }
    
    public double getDistancia() { return distancia; }
    public void setDistancia(double distancia) { this.distancia = distancia; }
    
    public int getTiempoEstimado() { return tiempoEstimado; }
    public void setTiempoEstimado(int tiempoEstimado) { this.tiempoEstimado = tiempoEstimado; }
    
    public List<Vehiculo> getVehiculosAsignados() { 
        return new ArrayList<>(vehiculosAsignados); // Defensive copy
    }
}
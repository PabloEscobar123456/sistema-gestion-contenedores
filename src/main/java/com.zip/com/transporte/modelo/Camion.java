package com.transporte.modelo;

/**
 * Clase que representa un camión en el sistema
 * @author SistemaTransporte
 */
public class Camion extends Vehiculo {
    private int numeroEjes;
    private boolean tieneRefrigeracion;
    
    /**
     * Constructor completo para camión
     * @param idVehiculo Identificador único
     * @param marca Marca del camión
     * @param modelo Modelo del camión
     * @param capacidadMaxima Capacidad en kg
     * @param numeroEjes Número de ejes del camión
     * @param tieneRefrigeracion Indica si tiene sistema de refrigeración
     */
    public Camion(String idVehiculo, String marca, String modelo, 
                  double capacidadMaxima, int numeroEjes, boolean tieneRefrigeracion) {
        super(idVehiculo, marca, modelo, capacidadMaxima);
        this.numeroEjes = numeroEjes;
        this.tieneRefrigeracion = tieneRefrigeracion;
    }
    
    // Getters y Setters
    public int getNumeroEjes() { return numeroEjes; }
    public void setNumeroEjes(int numeroEjes) { this.numeroEjes = numeroEjes; }
    
    public boolean isTieneRefrigeracion() { return tieneRefrigeracion; }
    public void setTieneRefrigeracion(boolean tieneRefrigeracion) { this.tieneRefrigeracion = tieneRefrigeracion; }
    
    @Override
    public double calcularEficiencia() {
        // TODO: Implementar algoritmo específico para camiones
        // Ejemplo: (capacidadMaxima / numeroEjes) * factorRefrigeracion
        throw new UnsupportedOperationException("Método no implementado");
    }
}